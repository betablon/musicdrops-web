MusicDrops — Press Kit
======================

MusicDrops is a music release tracker for iPhone and iPad. Follow your
favourite artists, and the moment a new album, single, or EP lands, you know.

  Website:  https://musicdrops.app
  App Store: https://apps.apple.com/us/app/music-drops/id6759535792
  Press:     hello@musicdrops.app

Contents
  icon/         App icon (1024px and 256px)
  screenshots/  iPhone and iPad captures (Following, Search, Drops timeline)

Usage
  These assets may be used freely in editorial coverage, reviews, and app
  round-ups about MusicDrops. Please keep the app icon as provided (no
  recolouring, distortion, or added effects), and don't use the name, icon,
  or screenshots to imply MusicDrops endorses another product.

  The screenshots show the MusicDrops interface. Artist names and album
  artwork shown within are the property of their respective owners and appear
  only as functional examples of the content the app surfaces from Apple's
  catalogue.

  Full fact sheet and boilerplate copy: https://musicdrops.app/press/
