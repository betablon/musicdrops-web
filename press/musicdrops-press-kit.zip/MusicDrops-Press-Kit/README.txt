MusicDrops Press Kit
====================

MusicDrops is a music release tracker for iPhone, iPad and iPhone Duo.
Follow your favourite artists, and when a new album, single or EP comes
out, MusicDrops lets you know: right away, once a day, or in a weekly
recap. Upcoming records show up once they're announced, and weekly and
monthly recaps sum up what came out.

  Website:   https://musicdrops.app
  App Store: https://apps.apple.com/app/id6759535792
  Press:     hello@musicdrops.app

Contents
  icon/                    App icon (1024 px and 256 px)
  screenshots/iphone/      iPhone, 1320 x 2868: Drops timeline, Upcoming
                           Drops, Following, Search
  screenshots/ipad/        iPad, landscape, 2752 x 2064: Drops timeline,
                           Following, Search
  screenshots/iphone-duo/  iPhone Duo: Drops timeline on the outer display
                           (1398 x 2034); Following and Search open flat
                           (2853 x 2007)

  All screenshots show MusicDrops 2.0.

Usage
  These assets may be used freely in editorial coverage, reviews and app
  round-ups about MusicDrops. Please keep the app icon as provided (no
  recolouring, distortion or added effects), and don't use the name, icon
  or screenshots to imply MusicDrops endorses another product.

  The screenshots show the MusicDrops interface. Artist names, photos and
  album artwork shown within are the property of their respective owners
  and appear only as functional examples of the content the app surfaces
  from Apple's catalogue.

  Full fact sheet and boilerplate copy: https://musicdrops.app/press/
